package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Main {
	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("SpEl.xml");
		Employee e=(Employee) ctx.getBean("employee");
		System.out.println(e.getEid());
		System.out.println(e.getEnm());
		System.out.println(e.getEsl());
		System.out.println(e.getEage());
		City city=e.geteCity();
		System.out.println(city.getName());
		
		
		}

}
