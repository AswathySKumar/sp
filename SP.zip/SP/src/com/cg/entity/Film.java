package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Film {
	@Id
private int filmid;
private String filmname;
private int filmtime;
public int getFilmid() {
	return filmid;
}
public void setFilmid(int filmid) {
	this.filmid = filmid;
}
public String getFilmname() {
	return filmname;
}
public void setFilmname(String filmname) {
	this.filmname = filmname;
}
public double getFilmtime() {
	return filmtime;
}
public void setFilmtime(int filmtime) {
	this.filmtime = filmtime;
}

}
