package com.cg.dao;

import java.util.List;

import com.cg.entity.Film;

public interface FilmRepository {
	

	public abstract List<Film> loadAll();
}
