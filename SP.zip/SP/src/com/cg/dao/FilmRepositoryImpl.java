package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.cg.entity.Film;
@Repository
public class FilmRepositoryImpl implements FilmRepository{
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Film> loadAll() {
TypedQuery<Film> query=entityManager.createQuery("SELECT e FROM Film e",Film.class);
		
		return query.getResultList();
	}

	}


