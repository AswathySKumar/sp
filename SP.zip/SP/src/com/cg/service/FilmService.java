package com.cg.service;

import java.util.List;

import com.cg.entity.Film;




//import com.cg.entity.Employee;

public interface FilmService {
	

	public abstract List<Film> loadAll();

	//public abstract List<Employee> loadAll();
}
