package com.control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CheckServlet
 */
@WebServlet("/Check.do")
public class CheckServlet extends HttpServlet {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	PrintWriter out=null;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException ,IOException {
	String user=req.getParameter("un");
	String pass=req.getParameter("pass");
	
	out=resp.getWriter();
	//Check.do?un=admin&pass=
	if((user.equals("admin"))&&(pass.equals("admin"))){
		out.println("valid customer");
		out.println("<html><head><title></title></head>");
		out.println("<body>");
		out.println("<a href=Check.do?id=1801&price=12000&size=12.1inch><img src=tv.jpeg height=300 width=300>");
		out.println("<a href=Check.do?id=1221&price=15000&size=5feet><img src=refridgerator.jpeg height=300 width=300>");
		out.println("<a href=Check.do?id=1101&price=10000&size=6.5inch><img src=phone1.jpeg height=300 width=300>");
		out.println("<a href=Check.do?id=1001&price=32000&size=12.1inch><img src=lap.jpeg height=300 width=300>");
	    out.println("</body>");
	    out.println("</html>");
	}
	else
	{
		//out.println("invalid customer");
		String i=req.getParameter("id");
		out.println(i);
		String in=req.getParameter("price");
		out.println(in);
		String ine=req.getParameter("size");
		out.println(ine);
		
		
		
	}
	
}
	
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp)
	throws ServletException, IOException {
	doGet(req, resp);
}
}
