package com.control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CheckServlet
 */
@WebServlet("Check.do")
public class CheckServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4104633877423343859L;
	PrintWriter out=null;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String user=req.getParameter("un");
		String pass=req.getParameter("pass");
		//int i=Integer.parseInt(pass);
		out=resp.getWriter();
		String aduser="aswathy";
		String apass="ash";
		if((user.equals(aduser))&&(pass.equals(apass))){
			out.println("valid customer");
		}
		else
		{
			out.println("invalid customer");
		}
		
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(req, resp);
	}
}
