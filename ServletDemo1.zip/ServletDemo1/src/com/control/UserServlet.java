package com.control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet(urlPatterns={"/user","user.aspx","user.php"})
public class UserServlet extends HttpServlet {
	public UserServlet() {
		System.out.println("i am servlet constructor");
	}
	
	PrintWriter out=null;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		//System.out.println("in do get");		
		out=resp.getWriter();
		out.println("<html><head><title></title></head>");
		out.println("<body>");
		out.println("<h1>welcome</h1>");
		int a=90; int b=900;
		if(a>b)
			out.println(a +"is greater ");
		else
			out.println(b+" is greater");
		out.println();
		out.println("hello");
		out.println("</body></html>");
		
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		//System.out.println("in do post");
	}
}
