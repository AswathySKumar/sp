package com.control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletCheck
 */
@WebServlet("/check.do")
public class ServletCheck extends HttpServlet {
	PrintWriter out=null;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String num=req.getParameter("numb");
		int i=Integer.parseInt(num);
		out=resp.getWriter();
		if(i%2==0){
			out.println(i+"number is even");
		}
		else
		{
			out.println(i+"number is odd");
		}
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(req, resp);
	}
}
